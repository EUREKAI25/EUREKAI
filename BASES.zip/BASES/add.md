
# SCRIPT
# FORMAT

# HOST
# SERVER
# CLOUDSERVER
# HOSTPROVIDER




# MAPPING

# GRID
# MODULE
# ACCORDION
# ANIMATION
# CSSANIMATION
# JSANIMATION
# DESIGN
# PALETTE
# GRAPHICCHART
# COLOR
# VIDEO
# IMAGE
# FORMAT
# DOCKER
# GITHUB
# TOOLS
# [TOOLS]DEVTOOLS
# PLATFORM
platform est un environnement technique ou logiciel qui sert de base à d’autres usages ou services.
# [SCHEMA]REGEX
# FILE
# DIRECTORY
# REPOSITORY
# TREE
# LANGUAGE
# NATURALLANGUAGE
# TECHNICALLANGUAGE
# DOCUMENTATION
# README
# HOWTO
# JSDATABASE
# SQLDATABASE
# DBFIELD
# DBQUERY
# DBROW
# SELECTQUERY
# DELETEQUERY
# UPDATEQUERY
# INSERTQUERY
# FILTERQUERY
# QUERYPARAMS
# QUERYORDER
# QUERYLIMIT
# ICONS
# BUNDLE
# NOMENCLATURE
# SPECIFICATION
# [TAG]HTMLTAG

# CATEGORY
# DESCRIPTION
# QUESTION
# NAME
# IDENT
# OBJECTDATA
# VALUE
# TOOL
Logiciel ou service spécialisé, focalisé sur une fonction précise.

## [TOOL]PAYMENT
Outils dédiés au paiement en ligne et à la gestion financière.
- Stripe
- PayPal

## [TOOL]MARKETING
Outils permettant l’automatisation et la gestion du marketing digital.
- Mailchimp
- HubSpot

## [TOOL]DESIGN
Outils dédiés à la création et au prototypage graphique.
- Figma
- Adobe XD
# COMPETITOR
# CHANNEL
# INFLUENCER
# ALERT
# DELAY
# PERIOD
# YEAR
# MEDIA
# MARKETING
# CAMPAIGN
# SEO
# EMAILING 
# SMS

#