# DATABASE
## RULE
### AUTOMATION 
Tout projet généré génère automatiquement un objet de type Database, lié à cet objet par related_to 


# TRIPLET
## RULE
Dans la bdd, on enregistre tout sous forme de triplet (<object_src>)
Tout objet de type triplet est forcément lié par depends_on à un objet de type Database
